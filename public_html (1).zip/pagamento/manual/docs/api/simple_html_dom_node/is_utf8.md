# is_utf8 (static)

```php
is_utf8 ( string $str ) : bool
```

| Parameter | Description
| --------- | -----------
| `str`     | String to test.

Returns true if the provided string is a valid UTF-8 string.